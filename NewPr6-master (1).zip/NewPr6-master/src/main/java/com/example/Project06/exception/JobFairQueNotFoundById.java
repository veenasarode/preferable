package com.example.Project06.exception;

public class JobFairQueNotFoundById extends RuntimeException{
    public JobFairQueNotFoundById(String message) {
        super(message);
    }
}
