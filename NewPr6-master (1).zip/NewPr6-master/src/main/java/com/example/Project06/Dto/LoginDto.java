package com.example.Project06.Dto;

public class LoginDto {
    public String mobileNo;
    public String email;
    public String password;
}
