package com.example.Project06.exception;

public class NoSavedTpoFoundException extends RuntimeException {
    public NoSavedTpoFoundException(String s) {
    }
}
