package com.example.Project06.exception;

public class JobFairQuenotFoundByQueTypeAndSetNo extends RuntimeException{
    public JobFairQuenotFoundByQueTypeAndSetNo(String message) {
        super(message);
    }
}
