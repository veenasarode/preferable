package com.example.Project06.exception;

public class SetNoNotFoundException extends RuntimeException {
    public SetNoNotFoundException(String message) {
        super(message);
    }
}
