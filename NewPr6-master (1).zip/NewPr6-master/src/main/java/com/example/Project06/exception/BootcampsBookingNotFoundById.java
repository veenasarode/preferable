package com.example.Project06.exception;

public class BootcampsBookingNotFoundById extends RuntimeException{
    public BootcampsBookingNotFoundById(String message) {
        super(message);
    }
}
