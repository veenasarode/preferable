package com.example.Project06.exception;

public class EmptyFiledException extends RuntimeException{
    public EmptyFiledException(String fillTheField) {
    }
}
