package com.example.Project06.Dto.JobfairQ2ans;

import lombok.Data;

@Data
public class JobfairQ2ansDto {
    public Integer JobFairQ1AnsId;
    public String question;
    public String ans;
    public Integer userId;
    public Integer jobId;
    public String questionType;
    public Integer jobFairQ1Id;
}
