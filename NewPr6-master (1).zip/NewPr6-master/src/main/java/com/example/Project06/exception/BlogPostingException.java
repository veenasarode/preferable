package com.example.Project06.exception;

import lombok.NoArgsConstructor;
@NoArgsConstructor
public class BlogPostingException  extends RuntimeException{


        public BlogPostingException(String s) {
        }

        public BlogPostingException(String s, String BlogPostingException) {
        }
    }



