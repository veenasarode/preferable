package com.example.Project06.exception;

public class JobFairQuestionDetailsNotFoundByJobId  extends RuntimeException{

    public JobFairQuestionDetailsNotFoundByJobId(String message) {
        super(message);

    }
}
