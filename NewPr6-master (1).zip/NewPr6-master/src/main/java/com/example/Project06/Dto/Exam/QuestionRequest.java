package com.example.Project06.Dto.Exam;

import lombok.Data;



@Data
public class QuestionRequest  {

        private Integer userId;
        private String subject;
        private String time;
    }


