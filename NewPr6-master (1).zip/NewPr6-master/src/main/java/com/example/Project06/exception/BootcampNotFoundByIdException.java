package com.example.Project06.exception;

public class BootcampNotFoundByIdException extends RuntimeException{
    public BootcampNotFoundByIdException(String message) {
        super(message);
    }
}
