package com.example.Project06.exception;

public class JobFairQueOneException extends RuntimeException{
    public JobFairQueOneException(String message) {
        super(message);
    }
}
