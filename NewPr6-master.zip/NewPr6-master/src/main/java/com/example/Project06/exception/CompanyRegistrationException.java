package com.example.Project06.exception;


public class CompanyRegistrationException extends RuntimeException {
    public CompanyRegistrationException(String message) {
        super(message);
    }
}