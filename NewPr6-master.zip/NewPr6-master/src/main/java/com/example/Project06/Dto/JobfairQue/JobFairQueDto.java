package com.example.Project06.Dto.JobfairQue;

import lombok.Getter;

@Getter
public class JobFairQueDto {

    public String question;

    public String questionType;

    public String setNo;
    public Integer jobId;
}
