package com.example.Project06.exception;

public class InvalidOtpException extends RuntimeException{

    public InvalidOtpException(String invalidOtp) {
    }
}