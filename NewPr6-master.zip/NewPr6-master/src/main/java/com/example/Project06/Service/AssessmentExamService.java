package com.example.Project06.Service;

import com.example.Project06.Dto.Exam.AssessmentExamDto;

public interface AssessmentExamService {


    void createAssessmentExam(AssessmentExamDto requestDTO);
}
