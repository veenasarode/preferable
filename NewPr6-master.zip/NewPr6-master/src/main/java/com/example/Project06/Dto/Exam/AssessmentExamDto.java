package com.example.Project06.Dto.Exam;


import lombok.Data;

@Data
public class AssessmentExamDto {

    private String subject;
    private String question;

}
