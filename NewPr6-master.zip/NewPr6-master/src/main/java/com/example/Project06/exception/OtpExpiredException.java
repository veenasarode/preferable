package com.example.Project06.exception;

public class OtpExpiredException extends RuntimeException {
    public OtpExpiredException(String otpHasExpired) {
    }
}
