package com.example.Project06.exception;

public class EmailNotVerifiedException extends RuntimeException {
    public EmailNotVerifiedException(String verifyEmailFirst) {
    }
}
