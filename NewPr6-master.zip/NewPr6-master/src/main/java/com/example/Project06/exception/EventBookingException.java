package com.example.Project06.exception;

import lombok.NoArgsConstructor;
@NoArgsConstructor
public class EventBookingException extends RuntimeException {

        public EventBookingException(String s) {
        }

        public EventBookingException(String s, String EventBookingException) {
        }
    }

